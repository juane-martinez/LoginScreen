<?php
$target_dir = "imagenes/";

// Obtener la fecha y hora actual
$fechaHora = date("Y-m-d H:i:s");

// Obtener la ubicación si está disponible
$latitude = $_POST["latitude"];
$longitude = $_POST["longitude"];

// Obtener el ID del paciente
$pacienteId = $_POST["pacienteId"]; // Asegúrate de que estás recibiendo este parámetro desde tu solicitud HTTP

// Nombre de archivo único basado en la fecha y hora actual
$target_file = $target_dir . $fechaHora . "_" . basename($_FILES["file"]["name"]);

if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
    
    include 'conexion.php';

    // Preparar la consulta SQL para insertar los datos en la tabla
    $sql = "INSERT INTO medicamentos (id_paciente, ruta_imagen, fecha_hora, latitud, longitud) VALUES ('$pacienteId', '$target_file', '$fechaHora', '$latitude', '$longitude')";

    if ($conexion->query($sql) === TRUE) {
        // Enviar respuesta JSON con el estado de la carga y la información
        $response = array(
            "status" => "success",
            "message" => "El archivo " . basename($_FILES["file"]["name"]) . " ha sido subido y los datos han sido insertados en la base de datos.",
            "fechaHora" => $fechaHora,
            "latitude" => $latitude,
            "longitude" => $longitude
        );
        echo json_encode($response);
    } else {
        // Enviar respuesta JSON con el error
        $response = array(
            "status" => "error",
            "message" => "Error al insertar los datos en la base de datos: " . $conexion->error
        );
        echo json_encode($response);
    }

    // Cerrar la conexión
    $conexion->close();
} else {
    // Enviar respuesta JSON con el error
    $response = array(
        "status" => "error",
        "message" => "Error al subir el archivo."
    );
    echo json_encode($response);
}
?>

