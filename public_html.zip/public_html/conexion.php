<?php
$hostname='localhost';
$database='id22148604_pharmabot_db';
$username='id22148604_admin';
$password='Pharmabotlab4@';

$conexion=new mysqli($hostname,$username,$password,$database);
if($conexion->connect_errno){
    echo "El sitio web está experimentado problemas";
}
?>