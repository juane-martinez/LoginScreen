<?php
// Verificar si la solicitud es de tipo POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los datos del formulario
    $fechaHora = $_POST["fechaHora"];
    $latitude = $_POST["latitude"];
    $longitude = $_POST["longitude"];
    $pacienteId = $_POST["pacienteId"];
    $medicamento = $_POST["medicamento"];
    $dosis = $_POST["dosis"];
    
    include "conexion.php";
    
    // Preparar la consulta SQL para insertar la información en la tabla Aplicaciones
    $sql = "INSERT INTO Aplicaciones (id_paciente, fecha_aplicacion, medicamento, dosis) VALUES (?, ?, ?, ?)";
    
    // Preparar la sentencia
    $stmt = $conexion->prepare($sql);
    // Vincular parámetros
    $stmt->bind_param("isss", $pacienteId, $fechaHora, $medicamento, $dosis);
    
    // Ejecutar la sentencia
    if ($stmt->execute()) {
        echo "success"; // Enviar respuesta de éxito al cliente
    } else {
        echo "error"; // Enviar respuesta de error al cliente
    }
    
    // Cerrar la conexión
    $stmt->close();
    $conexion->close();
} else {
    // Si la solicitud no es de tipo POST, responder con un mensaje de error
    echo "Error: Se esperaba una solicitud de tipo POST.";
}
?>

