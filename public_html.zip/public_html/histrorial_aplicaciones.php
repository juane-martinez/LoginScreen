<?php
include 'conexion.php';

$id_paciente = $_POST['id_paciente'];

$sentencia = $conexion->prepare("SELECT fecha_aplicacion, medicamento, dosis FROM Aplicaciones WHERE id_paciente = ?");
$sentencia->bind_param('i', $id_paciente);
$sentencia->execute();
$resultado = $sentencia->get_result();

$procedimientos = []; // Array para almacenar todos los procedimientos

while ($fila = $resultado->fetch_assoc()) {
    $procedimientos[] = $fila; // Añade cada fila de resultado al array
}

if (count($procedimientos) > 0) {
    echo json_encode($procedimientos, JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(['error' => 'No se encontraron procedimientos para el paciente']);
}

$sentencia->close();
$conexion->close();
?>