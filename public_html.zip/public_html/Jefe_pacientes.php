<?php
include 'conexion.php';

// Incluye las nuevas columnas en la consulta SQL
$query = "SELECT id_paciente, nombre, apellido, fecha_nacimiento, sexo, direccion, telefono FROM paciente";
$result = $conexion->query($query);

$pacientes = array();

while ($row = $result->fetch_assoc()) {
    $pacientes[] = $row;
}

echo json_encode($pacientes);
$conexion->close();
?>