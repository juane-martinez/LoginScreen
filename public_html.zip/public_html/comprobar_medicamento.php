<?php
// Incluye el archivo de conexión
include 'conexion.php';

// Verifica si se recibió la ID del paciente
if (isset($_GET['id_paciente'])) {
    $id_paciente = $_GET['id_paciente'];

    try {
        $sql = "SELECT medicamento, dosis FROM kardex WHERE id_paciente = ?";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("s", $id_paciente);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) {
            $response = array();
            while ($fila = $resultado->fetch_assoc()) {
                $response[] = $fila;
            }
            echo json_encode($response);
        } else {
            echo "No se encontraron medicamentos asociados al paciente.";
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }

    $stmt->close();
} else {
    echo "Error: No se recibió la ID del paciente.";
}

$conexion->close();
?>
