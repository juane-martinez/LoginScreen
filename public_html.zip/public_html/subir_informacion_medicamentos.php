<?php
include "conexion.php";

// Obtener los datos de la solicitud POST
$ruta_imagen = $_POST['ruta_imagen'];
$fecha_hora = $_POST['fecha_hora'];
$latitud = $_POST['latitud'];
$longitud = $_POST['longitud'];

// Preparar la consulta SQL para insertar los datos en la tabla
$sql = "INSERT INTO medicamentos (ruta_imagen, fecha_hora, latitud, longitud) VALUES ('$ruta_imagen', '$fecha_hora', $latitud, $longitud)";

// Ejecutar la consulta y verificar si fue exitosa
if ($conexion->query($sql) === TRUE) {
    echo "Datos insertados correctamente";
} else {
    echo "Error al insertar datos: " . $conexion->error;
}

// Cerrar la conexión
$conexion->close();
?>
