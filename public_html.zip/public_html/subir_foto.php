<?php
$target_dir = "imagenes/";
$target_file = $target_dir . basename($_FILES["file"]["name"]);

if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
    echo "El archivo ". basename($_FILES["file"]["name"]). " ha sido subido.";
} else {
    echo "Error al subir el archivo.";
}
?>
